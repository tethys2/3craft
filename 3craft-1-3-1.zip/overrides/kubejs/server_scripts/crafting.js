ServerEvents.recipes(e => {
    e.remove({ output: 'minecraft:blackstone', type: 'create:haunting' })
    e.remove({ output: 'minecraft:redstone', type: 'create:filling' })


    e.recipes.create.compacting('coal', '4x charcoal').heated()


    e.recipes.create.compacting('cobbled_deepslate', '2x cobblestone').heated()
    e.recipes.create.compacting('tuff', '2x gravel').heated()
    e.recipes.create.compacting('2x calcite', ['sandstone', 'diorite']).heated()
    e.recipes.create.compacting('3x create:limestone', ['2x sandstone', 'diorite']).heated()
    e.recipes.create.haunting('netherrack', 'cobblestone')
    e.recipes.create.haunting('blackstone', 'cobbled_deepslate')

    e.recipes.create.compacting('numismatics:sprocket', 'diamond').heated()
    e.recipes.create.filling('redstone', [Fluid.of('create:potion', 25, {Potion: 'minecraft:swiftness'}), 'create:cinder_flour'])

    let inter = 'kubejs:incomplete_netherite_scrap' // making a variable to store the transitional item makes the code more readable
	e.recipes.create.sequenced_assembly([
		Item.of('netherite_scrap').withChance(16.0), // this is the item that will appear in JEI as the result
		Item.of('blackstone').withChance(16.0), // the rest of these items will be part of the scrap
	], 'blackstone', [ // 'flowering_azalea_leaves' is the input
		// the transitional item is a variable, that is 'kubejs:incomplete_spore_blossom' and is used during the intermediate stages of the assembly
		e.recipes.createPressing(inter, inter),
		// like a normal recipe function, is used as a sequence step in this array. Input and output have the transitional item
		e.recipes.createDeploying(inter, [inter, 'blackstone']),
		e.recipes.createFilling(inter, [inter, Fluid.lava(100)]),
	]).transitionalItem(inter).loops(64) // set the transitional item and the number of loops
    inter = 'kubejs:incomplete_diamond' // making a variable to store the transitional item makes the code more readable
	e.recipes.create.sequenced_assembly([
		Item.of('diamond').withChance(16.0), // this is the item that will appear in JEI as the result
		Item.of('coal').withChance(16.0), // the rest of these items will be part of the scrap
	], 'coal', [ // 'flowering_azalea_leaves' is the input
		// the transitional item is a variable, that is 'kubejs:incomplete_spore_blossom' and is used during the intermediate stages of the assembly
		e.recipes.createPressing(inter, inter),
		// like a normal recipe function, is used as a sequence step in this array. Input and output have the transitional item
		e.recipes.createDeploying(inter, [inter, 'coal']),
		e.recipes.createFilling(inter, [inter, Fluid.lava(100)]),
	]).transitionalItem(inter).loops(64) // set the transitional item and the number of loops

    

})