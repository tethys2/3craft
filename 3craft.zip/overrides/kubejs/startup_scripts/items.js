StartupEvents.registry('item', e => {
    e.create('incomplete_netherite_scrap', 'create:sequenced_assembly')
    e.create('incomplete_diamond', 'create:sequenced_assembly')
})