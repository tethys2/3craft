ServerEvents.recipes(e => {
    e.remove({ output: 'minecraft:blackstone', type: 'create:haunting' })
    e.remove({ output: 'minecraft:redstone', type: 'create:filling' })


    e.recipes.create.compacting('coal', '4x charcoal').heated()


    e.recipes.create.compacting('cobbled_deepslate', '2x cobblestone').heated()
    e.recipes.create.compacting('tuff', '2x gravel').heated()
    e.recipes.create.splashing('calcite', 'create:limestone')
    e.recipes.create.compacting('create:limestone', '2x bone_block').heated()
    e.recipes.create.haunting('netherrack', 'cobblestone')
    e.recipes.create.haunting('blackstone', 'cobbled_deepslate')

    e.recipes.create.compacting('numismatics:sprocket', 'diamond').heated()
    e.recipes.create.filling('redstone', [Fluid.of('create:potion', 25, {Potion: 'minecraft:swiftness'}), 'create:cinder_flour'])

    e.recipes.create.compacting(Item.of('diamond').withChance(0.015625), 'coal').superheated()
    e.recipes.create.compacting(Item.of('netherite_scrap').withChance(0.015625), '16x blackstone').superheated()

})