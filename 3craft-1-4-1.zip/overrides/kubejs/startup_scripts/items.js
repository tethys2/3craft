StartupEvents.registry('item', e => {
})